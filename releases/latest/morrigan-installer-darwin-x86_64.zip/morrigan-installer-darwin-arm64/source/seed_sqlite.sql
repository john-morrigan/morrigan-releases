INSERT INTO event_queue (
    created_at, trigger_utc, io_utc, utc_zone, endpoint_id, 
    file_id, action_type, file_type, file_size, action_source, target_source, 
    hu_per, sent
) VALUES
-- Copy events from various LLM domains (removed id to avoid conflicts)
('2025-07-06 22:26:15', '2025-07-06T22:26:15.123456+00:00', '2025-07-06T22:16:28.187716+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'no-file', 'Copy', '', 456, 'Google Chrome', 'clipboard', 15, 0),
('2025-07-06 22:27:32', '2025-07-06T22:27:32.234567+00:00', '2025-07-06T22:16:28.187716+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'no-file', 'Copy', '', 1024, 'Microsoft Edge', 'clipboard', 25, 0),
('2025-07-06 22:28:45', '2025-07-06T22:28:45.345678+00:00', '2025-07-06T22:16:28.187716+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'no-file', 'Paste', '', 789, 'Code', 'clipboard', 30, 0),
('2025-07-06 22:29:18', '2025-07-06T22:29:18.456789+00:00', '2025-07-06T22:16:28.330117+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'a1b2c3d4e5f6', 'Save', '', 120, 'Code', 'desktop', 45, 0),
('2025-07-06 22:30:02', '2025-07-06T22:30:02.567890+00:00', '2025-07-06T22:16:28.187716+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'no-file', 'Copy', '', 2156, 'Safari', 'clipboard', 35, 0),
-- File operations
('2025-07-06 22:31:15', '2025-07-06T22:31:15.678901+00:00', '2025-07-06T22:16:28.330117+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'f7e8d9c0b1a2', 'Download', '/Users/johnhill/Downloads/document.pdf', 524288, 'Google Chrome', 'file', 10, 0),
('2025-07-06 22:32:28', '2025-07-06T22:32:28.789012+00:00', '2025-07-06T22:16:28.330117+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'b3c4d5e6f7a8', 'Save', '/Users/johnhill/Documents/code.py', 4096, 'Code', 'file', 40, 0),
('2025-07-06 22:33:41', '2025-07-06T22:33:41.890123+00:00', '2025-07-06T22:16:28.187716+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'no-file', 'Copy', '', 892, 'Firefox', 'clipboard', 20, 0),
('2025-07-06 22:34:54', '2025-07-06T22:34:54.901234+00:00', '2025-07-06T22:16:28.330117+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'c5d6e7f8a9b0', 'Create', '/Users/johnhill/Desktop/notes.txt', 2048, 'TextEdit', 'file', 5, 0),
('2025-07-06 22:35:07', '2025-07-06T22:35:07.012345+00:00', '2025-07-06T22:16:28.187716+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'no-file', 'Copy', '', 1567, 'Google Chrome', 'clipboard', 50, 0),
-- More varied events
('2025-07-06 22:36:20', '2025-07-06T22:36:20.123457+00:00', '2025-07-06T22:16:28.330117+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'd7e8f9a0b1c2', 'Upload', '/Users/johnhill/Documents/image.png', 1048576, 'Google Chrome', 'file', 15, 0),
('2025-07-06 22:37:33', '2025-07-06T22:37:33.234568+00:00', '2025-07-06T22:16:28.187716+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'no-file', 'Paste', '', 345, 'Code', 'clipboard', 25, 0),
('2025-07-06 22:38:46', '2025-07-06T22:38:46.345679+00:00', '2025-07-06T22:16:28.330117+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'e9f0a1b2c3d4', 'Save', '', 89, 'Terminal', 'desktop', 10, 0),
('2025-07-06 22:39:59', '2025-07-06T22:39:59.456780+00:00', '2025-07-06T22:16:28.187716+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'no-file', 'Copy', '', 3421, 'Microsoft Edge', 'clipboard', 45, 0),
('2025-07-06 22:41:12', '2025-07-06T22:41:12.567891+00:00', '2025-07-06T22:16:28.330117+00:00', 'UTC', '04f9c843-2aa6-45a5-aead-0e99bfd09a8a', 'f1a2b3c4d5e6', 'Save', '/Users/johnhill/Downloads/config.json', 1024, 'Code', 'file', 30, 0);