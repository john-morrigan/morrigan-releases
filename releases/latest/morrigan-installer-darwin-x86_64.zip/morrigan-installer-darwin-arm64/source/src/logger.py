import logging
import logging.handlers
import sys
import os
from pathlib import Path
from .config import Config


def is_executable() -> bool:
    """Check if running as a PyInstaller executable"""
    return hasattr(sys, '_MEIPASS') or getattr(sys, 'frozen', False)


def get_executable_log_path() -> Path:
    """Get log file path when running as executable"""
    if hasattr(sys, '_MEIPASS'):
        # PyInstaller bundle
        exe_dir = Path(sys.executable).parent
    elif getattr(sys, 'frozen', False):
        # Other freezing tools
        exe_dir = Path(sys.executable).parent
    else:
        # Fallback to current directory
        exe_dir = Path.cwd()
    
    return exe_dir / "morrigan_output.log"


def setup_logging() -> logging.Logger:
    Config.ensure_data_directory()

    logger = logging.getLogger("morrigan")
    logger.setLevel(getattr(logging, Config.LOG_LEVEL))

    logger.handlers.clear()

    formatter = logging.Formatter(Config.LOG_FORMAT)
    
    # Check if running as executable
    running_as_exe = is_executable()

    # Console logging - disable for executables unless explicitly enabled
    if Config.LOG_TO_CONSOLE and not running_as_exe:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    # Standard file logging (in data directory)
    try:
        file_handler = logging.handlers.RotatingFileHandler(
            Config.LOG_FILE,
            maxBytes=10*1024*1024,
            backupCount=5
        )
        file_handler.setLevel(getattr(logging, Config.LOG_LEVEL))
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        # If we can't log to standard location, try alternative
        if running_as_exe:
            try:
                alt_log_path = get_executable_log_path()
                file_handler = logging.handlers.RotatingFileHandler(
                    alt_log_path,
                    maxBytes=10*1024*1024,
                    backupCount=3
                )
                file_handler.setLevel(getattr(logging, Config.LOG_LEVEL))
                file_handler.setFormatter(formatter)
                logger.addHandler(file_handler)
                logger.info(f"Using alternative log location: {alt_log_path}")
            except Exception as alt_e:
                # Last resort - try to write to temp
                try:
                    import tempfile
                    temp_log = Path(tempfile.gettempdir()) / "morrigan_emergency.log"
                    temp_handler = logging.FileHandler(temp_log)
                    temp_handler.setLevel(logging.ERROR)
                    temp_handler.setFormatter(formatter)
                    logger.addHandler(temp_handler)
                    logger.error(f"Emergency logging to: {temp_log}")
                except:
                    pass  # Give up on file logging
        else:
            logger.warning(f"Could not setup file logging: {e}")

    # When running as executable, always add an output log in executable directory
    if running_as_exe and Config.EXECUTABLE_LOG_ENABLED:
        try:
            exe_log_path = get_executable_log_path()
            exe_handler = logging.handlers.RotatingFileHandler(
                exe_log_path,
                maxBytes=5*1024*1024,  # Smaller size for executable output
                backupCount=2
            )
            # Use configurable log level for executable output
            exe_handler.setLevel(getattr(logging, Config.EXECUTABLE_LOG_LEVEL))
            
            # Use a more detailed format for executable output
            exe_formatter = logging.Formatter(
                "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
            )
            exe_handler.setFormatter(exe_formatter)
            logger.addHandler(exe_handler)
            
            logger.info(f"Executable output logging to: {exe_log_path}")
            logger.info(f"Running as executable: {sys.executable}")
            logger.info(f"Executable log level: {Config.EXECUTABLE_LOG_LEVEL}")
            
        except Exception as e:
            logger.error(f"Could not setup executable output logging: {e}")

    return logger


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"morrigan.{name}")


setup_logging()
