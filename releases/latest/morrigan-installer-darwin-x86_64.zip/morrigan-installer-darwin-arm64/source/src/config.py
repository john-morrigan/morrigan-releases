import os
import platform
import json
from datetime import datetime, timedelta
from typing import List, Set, Optional
from pathlib import Path

try:
    from dotenv import load_dotenv
    
    # Try to load .env from multiple locations
    env_paths = [
        Path.cwd() / ".env",  # Current directory
        Path(__file__).parent.parent / ".env",  # Project root
        Path("/opt/morrigan/.env") if platform.system() != "Windows" else Path("C:/Program Files/Morrigan/.env"),  # Installation directory
    ]
    
    env_loaded = False
    for env_path in env_paths:
        if env_path.exists():
            load_dotenv(env_path)
            env_loaded = True
            break
    
    if not env_loaded:
        # Try default location as fallback
        load_dotenv()
        
except ImportError:
    pass


class Config:

    IS_WINDOWS = platform.system() == "Windows"
    IS_DEVELOPMENT = os.getenv("ENV", "production") == "development"
    API_BASE_URL = os.getenv("API_URL", "https://morrigan-poc-serverless.azurewebsites.net/api")

    # Support both API_KEY and API_TOKEN for backward compatibility
    API_KEY = os.getenv("API_KEY") or os.getenv("API_TOKEN") or ""

    API_TIMEOUT = 30
    
    # Token storage paths
    if IS_WINDOWS:
        ENDPOINT_ID_PATH = Path("C:/ProgramData/Morrigan/endpoint_id.txt")
        DATA_DIR = Path("C:/ProgramData/Morrigan")
        TOKEN_PATH = Path("C:/ProgramData/Morrigan/auth_token.json")
    else:
        ENDPOINT_ID_PATH = Path.home() / ".morrigan" / "endpoint_id.txt"
        DATA_DIR = Path.home() / ".morrigan"
        TOKEN_PATH = Path.home() / ".morrigan" / "auth_token.json"
    DATABASE_PATH = DATA_DIR / "events.db"
    MAX_QUEUE_SIZE = 100
    MAX_QUEUE_SIZE_MB = 10
    CLIPBOARD_THRESHOLD = 300
    LARGE_FILE_THRESHOLD = 1024 * 1024
    # FYI Windows only
    MONITORED_PATHS = [
        "~/Desktop",
        "~/Documents",
        "~/Downloads"
    ] if not IS_WINDOWS else [
        "C:/Users/{username}/Desktop",
        "C:/Users/{username}/Documents",
        "C:/Users/{username}/Downloads"
    ]

    LLM_DOMAINS: Set[str] = {
        "chat.openai.com",
        "copilot.microsoft.com",
        "bard.google.com",
        "claude.ai",
        "github.com",
        "gemini.google.com",
        "poe.com",
        "perplexity.ai",
        "character.ai"
    }

    ACTION_TYPES = {
        "copy": "Copy",
        "paste": "Paste",
        "download": "Download",
        "upload": "Upload",
        "create": "Create",
        "save": "Save"
    }
    BATCH_SIZE = 50
    BATCH_TIMEOUT = 24 * 60 * 60

    RETRY_INITIAL_DELAY = 5
    RETRY_MAX_DELAY = 15 * 60
    RETRY_MULTIPLIER = 2
    RETRY_MAX_ATTEMPTS = 10

    IS_PRODUCTION = os.getenv("MORRIGAN_MODE", "production") == "production"
    SILENT_MODE = IS_PRODUCTION or os.getenv("MORRIGAN_SILENT", "false").lower() == "true"
    AUTO_START = IS_PRODUCTION or os.getenv("MORRIGAN_AUTO_START", "false").lower() == "true"

    LOG_LEVEL = "ERROR" if IS_PRODUCTION else os.getenv("LOG_LEVEL", "INFO")
    LOG_TO_CONSOLE = not SILENT_MODE

    LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    LOG_FILE = DATA_DIR / "morrigan.log"
    
    # Executable-specific logging settings
    EXECUTABLE_LOG_LEVEL = os.getenv("EXECUTABLE_LOG_LEVEL", "INFO")
    EXECUTABLE_LOG_ENABLED = os.getenv("EXECUTABLE_LOG_ENABLED", "true").lower() == "true"

    @classmethod
    def ensure_data_directory(cls) -> None:
        cls.DATA_DIR.mkdir(parents=True, exist_ok=True)

    @classmethod
    def get_stored_token(cls) -> Optional[str]:
        """Get stored bearer token if still valid"""
        try:
            if not cls.TOKEN_PATH.exists():
                return None
                
            with open(cls.TOKEN_PATH, 'r') as f:
                token_data = json.load(f)
                
            # Check if token is still valid (with 1 hour buffer)
            expiry = datetime.fromisoformat(token_data['expires_at'])
            buffer_time = datetime.now() + timedelta(hours=1)
            
            if expiry > buffer_time:
                return token_data['token']
            else:
                # Token expired, remove it
                cls.TOKEN_PATH.unlink(missing_ok=True)
                return None
                
        except Exception:
            # If there's any error reading the token, remove the file
            cls.TOKEN_PATH.unlink(missing_ok=True)
            return None

    @classmethod
    def store_token(cls, token: str, expires_in_days: int = 30) -> None:
        """Store bearer token with expiry date"""
        try:
            cls.ensure_data_directory()
            
            expiry = datetime.now() + timedelta(days=expires_in_days)
            token_data = {
                'token': token,
                'expires_at': expiry.isoformat(),
                'created_at': datetime.now().isoformat()
            }
            
            with open(cls.TOKEN_PATH, 'w') as f:
                json.dump(token_data, f, indent=2)
                
        except Exception as e:
            from .logger import get_logger
            logger = get_logger(__name__)
            logger.error(f"Failed to store auth token: {e}")

    @classmethod
    def clear_token(cls) -> None:
        """Clear stored token"""
        cls.TOKEN_PATH.unlink(missing_ok=True)

    @classmethod
    def get_monitored_paths(cls, username: Optional[str] = None) -> List[Path]:
        if not cls.IS_WINDOWS:
            return [Path(path).expanduser() for path in cls.MONITORED_PATHS]

        if not username:
            username = os.getenv("USERNAME", "")

        paths = []
        for path_template in cls.MONITORED_PATHS:
            path_str = path_template.format(username=username)
            paths.append(Path(path_str))
        return paths

    @classmethod
    def is_llm_domain(cls, url: str) -> bool:
        if not url:
            return False

        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
            for llm_domain in cls.LLM_DOMAINS:
                if domain == llm_domain or domain.endswith(f".{llm_domain}"):
                    return True
            return False
        except Exception:
            return False

    @classmethod
    def validate_config(cls) -> List[str]:
        issues = []

        if not cls.API_BASE_URL:
            issues.append("API_BASE_URL environment variable not set or empty")

        try:
            from .endpoint import endpoint_manager
            endpoint_id = endpoint_manager.get_endpoint_id()
            if not endpoint_id:
                issues.append("Unable to get or generate endpoint_id")
        except Exception as e:
            issues.append(f"Error accessing endpoint_id: {e}")

        return issues
