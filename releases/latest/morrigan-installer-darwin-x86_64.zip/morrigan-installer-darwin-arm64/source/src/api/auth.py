import json
import requests
from typing import Optional, Dict, Any
from dataclasses import dataclass

from ..config import Config
from ..logger import get_logger

logger = get_logger(__name__)


@dataclass
class AuthResponse:
    success: bool
    token: Optional[str] = None
    error: Optional[str] = None
    status_code: Optional[int] = None


class AuthManager:
    """Manages bearer token authentication for API requests"""
    
    def __init__(self):
        self._cached_token: Optional[str] = None
    
    def get_token(self, endpoint_id: str, force_refresh: bool = False) -> Optional[str]:
        """Get a valid bearer token, refreshing if necessary"""
        
        # Return cached token if available and not forced to refresh
        if not force_refresh and self._cached_token:
            return self._cached_token
            
        # Try to get stored token first
        if not force_refresh:
            stored_token = Config.get_stored_token()
            if stored_token:
                self._cached_token = stored_token
                return stored_token
        
        # Need to fetch new token
        auth_response = self._fetch_token(endpoint_id)
        if auth_response.success and auth_response.token:
            self._cached_token = auth_response.token
            Config.store_token(auth_response.token)
            return auth_response.token
            
        logger.error(f"Failed to get auth token: {auth_response.error}")
        return None
    
    def _fetch_token(self, endpoint_id: str) -> AuthResponse:
        """Fetch a new token from the auth endpoint"""
        try:
            auth_url = f"{Config.API_BASE_URL}/auth/token"
            payload = {"endpoint_id": endpoint_id}
            
            logger.info(f"Requesting auth token for endpoint_id: {endpoint_id}")
            
            response = requests.post(
                auth_url,
                json=payload,
                headers={'Content-Type': 'application/json'},
                timeout=Config.API_TIMEOUT
            )
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    token = data.get('access_token')  # Azure API returns 'access_token', not 'token'
                    if token:
                        logger.info("Successfully obtained JWT access token")
                        return AuthResponse(success=True, token=token)
                    else:
                        return AuthResponse(
                            success=False, 
                            error="Token not found in response",
                            status_code=response.status_code
                        )
                except json.JSONDecodeError:
                    return AuthResponse(
                        success=False,
                        error="Invalid JSON response from auth endpoint",
                        status_code=response.status_code
                    )
            else:
                error_msg = f"Auth request failed with status {response.status_code}"
                try:
                    error_data = response.json()
                    if 'error' in error_data:
                        error_msg += f": {error_data['error']}"
                except json.JSONDecodeError:
                    error_msg += f": {response.text}"
                    
                logger.warning(error_msg)
                return AuthResponse(
                    success=False,
                    error=error_msg,
                    status_code=response.status_code
                )
                
        except requests.exceptions.Timeout:
            error_msg = "Auth request timed out"
            logger.warning(error_msg)
            return AuthResponse(success=False, error=error_msg, status_code=408)
            
        except requests.exceptions.ConnectionError:
            error_msg = "Could not connect to auth endpoint"
            logger.warning(error_msg)
            return AuthResponse(success=False, error=error_msg, status_code=503)
            
        except Exception as e:
            error_msg = f"Unexpected error during authentication: {str(e)}"
            logger.error(error_msg)
            return AuthResponse(success=False, error=error_msg, status_code=500)
    
    def clear_token(self) -> None:
        """Clear cached and stored tokens"""
        self._cached_token = None
        Config.clear_token()
        logger.info("Cleared auth tokens")
    
    def test_token(self, token: str) -> bool:
        """Test if a token is valid by making a test request"""
        try:
            response = requests.get(
                f"{Config.API_BASE_URL}/health",
                headers={'Authorization': f'Bearer {token}'},
                timeout=Config.API_TIMEOUT
            )
            return response.status_code == 200
        except Exception:
            return False


# Global auth manager instance
auth_manager = AuthManager()
