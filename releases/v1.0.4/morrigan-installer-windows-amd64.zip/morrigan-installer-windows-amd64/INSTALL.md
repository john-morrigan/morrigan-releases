# Morrigan Installation Guide

## Overview

This guide covers the complete installation process for Morrigan using the self-contained installer packages.

## System Requirements

- **Operating System**: Windows 10+, macOS 10.14+, or Linux (Ubuntu 18.04+)
- **Python**: Version 3.8 or higher
- **Privileges**: Administrator/root access for installation
- **Internet**: Required for dependency installation
- **Disk Space**: Minimum 50MB free space

## Download

Select the appropriate installer package for your platform:

- **Windows**: `morrigan-installer-windows-amd64.zip`
- **macOS (Apple Silicon)**: `morrigan-installer-darwin-arm64.zip`
- **macOS (Intel)**: `morrigan-installer-darwin-x86_64.zip`
- **Linux**: `morrigan-installer-linux-x86_64.zip`

## Installation Process

### 1. Extract the Package

Extract the downloaded ZIP file to a convenient location. The package contains:

```
morrigan-installer-{platform}-{arch}/
├── MorriganInstaller           # Self-contained installer executable
├── INSTALL.md                  # This installation guide
├── QUICK_START.md             # Quick reference guide
├── TROUBLESHOOTING.md         # General troubleshooting
└── MACOS_TROUBLESHOOTING.md   # macOS-specific help (macOS only)
```

### 2. Run the Installer

**Windows:**
```cmd
# Right-click MorriganInstaller.exe and "Run as administrator"
# Or from Command Prompt (as administrator):
MorriganInstaller.exe
```

**macOS:**
```bash
# If you see "Apple cannot verify" warning, see MACOS_TROUBLESHOOTING.md
chmod +x MorriganInstaller
sudo ./MorriganInstaller
```

**Linux:**
```bash
chmod +x MorriganInstaller
sudo ./MorriganInstaller
```

### 3. Follow Installation Prompts

The installer will:
1. Check system requirements
2. Create application directories
3. Install Python dependencies in a virtual environment
4. Deploy application files
5. Configure the system service
6. Verify the installation

### 4. Provide Configuration

During installation, you'll be prompted for:

- **API URL**: The base URL for the Morrigan API service
- **API Key**: Your authentication token (keep this secure)
- **Installation Path**: Accept default or specify custom location

## Post-Installation

### Verification

After installation, verify Morrigan is running:

**Windows:**
```cmd
sc query MorriganService
```

**macOS/Linux:**
```bash
# Check if the service is running
ps aux | grep morrigan
```

### Configuration File

The configuration is stored in:
- **Windows**: `C:\ProgramData\Morrigan\.env`
- **macOS/Linux**: `~/.morrigan/.env`

You can edit this file to update settings after installation.

## Troubleshooting

For detailed troubleshooting information, see:
- `TROUBLESHOOTING.md` - General issues and solutions
- `MACOS_TROUBLESHOOTING.md` - macOS-specific security warnings (macOS only)

### Common Issues

**Python Not Found:**
- Install Python 3.8+ from python.org
- Ensure Python is in your system PATH

**Permission Denied:**
- Run installer with administrator/sudo privileges
- Check that your user has write access to installation directory

**macOS Security Warning:**
- See MACOS_TROUBLESHOOTING.md for detailed steps
- Allow the application in System Preferences > Security & Privacy

**Installation Fails:**
- Check internet connection for dependency downloads
- Verify sufficient disk space
- Review error messages in the installer output

## Uninstallation

To remove Morrigan:

**Windows:**
- Use "Add or Remove Programs" in Windows Settings
- Or run: `MorriganInstaller.exe --uninstall`

**macOS/Linux:**
```bash
sudo /opt/morrigan/uninstall.sh
# Or manually remove:
sudo rm -rf /opt/morrigan
sudo rm -rf ~/.morrigan  # User data
```

## Security Notes

- The installer contains all necessary application code embedded within the executable
- No source code files are distributed to end users
- All application data is securely packaged and deployed during installation
- Configuration files are created with appropriate permissions

## Support

If you encounter issues not covered in the troubleshooting guides:
1. Check the log files in the application data directory
2. Contact your system administrator
3. Provide installer output and error messages for diagnosis
