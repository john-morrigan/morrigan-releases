# Troubleshooting Guide

## Installation Issues

### Installation Taking Too Long
- **Expected time**: 2-7 minutes total
- **Most time spent**: Installing Python dependencies (1-5 minutes)
- **See**: `TIMING_GUIDE.md` for detailed timing expectations

**Solutions:**
- Check internet connection (pip downloads packages)
- Wait longer - dependency installation can be slow
- Try running in a location with better internet
- Clear pip cache: `python -m pip cache purge`

### Python Not Found

**Error**: "Python not found" or "Python command not recognized"

**Solutions**:
1. Install Python 3.8 or higher from python.org
2. Ensure Python is added to system PATH during installation
3. Try alternative commands:
   ```bash
   python3 --version  # Linux/macOS
   py --version       # Windows
   ```

### Permission Denied

**Error**: "Permission denied" or "Access denied"

**Solutions**:
1. Run installer with administrator privileges:
   - **Windows**: Right-click installer, select "Run as administrator"
   - **macOS/Linux**: Use `sudo ./MorriganInstaller`
2. Check file permissions: `chmod +x MorriganInstaller`
3. Verify user has write access to installation directory

### Dependency Installation Failures

**Error**: "Failed to install required dependencies"

**Solutions**:
1. Check internet connection
2. Update pip: `python -m pip install --upgrade pip`
3. Install dependencies manually:
   ```bash
   pip install psutil requests pyperclip watchdog python-dotenv
   ```
4. Use virtual environment if system packages conflict

### Disk Space Issues

**Error**: "No space left on device" or "Insufficient disk space"

**Solutions**:
1. Free up at least 100MB of disk space
2. Choose different installation directory with more space
3. Clean temporary files and caches

## Runtime Issues

### Service Not Starting

**Symptoms**: Morrigan service fails to start after installation

**Diagnostics**:
```bash
# Check service status
# Windows:
sc query MorriganService

# macOS:
launchctl list | grep morrigan

# Linux:
systemctl status morrigan
```

**Solutions**:
1. Check log files in data directory for errors
2. Verify configuration file is valid
3. Restart service manually:
   ```bash
   # Windows:
   sc start MorriganService
   
   # macOS:
   launchctl load ~/Library/LaunchAgents/com.morrigan.monitor.plist
   
   # Linux:
   sudo systemctl start morrigan
   ```

### Configuration Issues

**Error**: "Invalid configuration" or API connection failures

**Solutions**:
1. Verify API credentials in configuration file:
   - **Windows**: `C:\ProgramData\Morrigan\.env`
   - **macOS/Linux**: `~/.morrigan/.env`
2. Test API connectivity:
   ```bash
   curl -H "Authorization: Bearer YOUR_API_KEY" YOUR_API_URL/health
   ```
3. Check network firewall settings
4. Verify API URL format (should include protocol: https://)

### File Access Issues

**Error**: "Cannot access file" or "File not found"

**Solutions**:
1. Check file permissions in installation directory
2. Verify antivirus software isn't blocking files
3. Run application with elevated privileges temporarily
4. Check if files are locked by another process

## Platform-Specific Issues

### Windows

**Antivirus Software Blocking**:
- Add installation directory to antivirus exclusions
- Temporarily disable real-time protection during installation

**Windows Service Issues**:
```cmd
# Restart service
sc stop MorriganService
sc start MorriganService

# Reinstall service
sc delete MorriganService
# Run installer again
```

### macOS

**Security Warnings**: See MACOS_TROUBLESHOOTING.md for detailed instructions

**Permissions Issues**:
```bash
# Reset permissions
sudo chown -R $(whoami) ~/.morrigan
sudo chmod -R 755 /opt/morrigan
```

### Linux

**Systemd Service Issues**:
```bash
# Reload systemd configuration
sudo systemctl daemon-reload

# Enable and start service
sudo systemctl enable morrigan
sudo systemctl start morrigan

# Check service logs
journalctl -u morrigan -f
```

**Package Manager Conflicts**:
- Use `--user` flag with pip if system packages conflict
- Consider using virtual environment for Python dependencies

## Network and Connectivity

### Firewall Issues

**Symptoms**: API calls fail or timeout

**Solutions**:
1. Check firewall settings for outbound HTTPS connections
2. Add API domain to firewall allowlist
3. Configure proxy settings if behind corporate firewall
4. Test connectivity: `telnet api-domain.com 443`

### Proxy Configuration

For corporate networks with proxies:
1. Set environment variables:
   ```bash
   export HTTP_PROXY=http://proxy:port
   export HTTPS_PROXY=https://proxy:port
   ```
2. Configure pip for proxy:
   ```bash
   pip install --proxy http://proxy:port package_name
   ```

## Log Files and Diagnostics

### Log Locations

- **Windows**: `C:\ProgramData\Morrigan\morrigan.log`
- **macOS/Linux**: `~/.morrigan/morrigan.log`

### Useful Diagnostic Commands

```bash
# Check Python installation
python --version
pip --version

# Check available disk space
df -h  # Linux/macOS
dir    # Windows

# Check network connectivity
ping google.com
nslookup your-api-domain.com

# Check process status
ps aux | grep morrigan  # Linux/macOS
tasklist | findstr Morrigan  # Windows
```

### Collecting Support Information

When contacting support, include:
1. Operating system and version
2. Python version
3. Error messages from installer
4. Log file contents
5. Network configuration details
6. Antivirus software information

## Recovery Procedures

### Clean Reinstallation

1. Uninstall existing installation:
   ```bash
   # Windows:
   MorriganInstaller.exe --uninstall
   
   # macOS/Linux:
   sudo /opt/morrigan/uninstall.sh
   ```

2. Remove residual files:
   ```bash
   # Windows:
   rmdir /s "C:\ProgramData\Morrigan"
   
   # macOS/Linux:
   rm -rf ~/.morrigan
   sudo rm -rf /opt/morrigan
   ```

3. Run installer again

### Manual Installation Fallback

If automated installation fails:
1. Extract application files manually
2. Install Python dependencies: `pip install -r requirements.txt`
3. Copy configuration template and customize
4. Start application manually to test
5. Configure service/autostart manually if needed

Contact support if issues persist after following these troubleshooting steps.
