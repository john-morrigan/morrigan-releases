# Quick Start Guide

## For Developers

### Complete Release Workflow

#### Option 1: One-Command Release (Recommended)

```bash
# Complete end-to-end release for current platform
python installer/scripts/release_complete.py --version v1.1.0

# Build for all platforms and clean up afterwards
python installer/scripts/release_complete.py --version v1.1.0 --all-platforms --cleanup

# Use legacy separate repository mode
python installer/scripts/release_complete.py --version v1.1.0 --no-submodule
```

#### Option 2: Step-by-Step Process

```bash
# Step 1: Build self-contained installer
python installer/scripts/build_selfcontained.py

# Step 2: Create distribution packages
python installer/scripts/create_distribution.py --current

# Step 3: Update releases repository using git submodules
python installer/scripts/update_releases.py --version v1.1.0
```

This creates:
- Self-contained installer executable with embedded application code
- Distribution ZIP packages in `dist/` folder ready for distribution
- Updates the morrigan-releases submodule with the new distribution
- Commits and pushes changes to the submodule automatically

### Git Submodule Setup (First Time Only)

If you haven't set up the git submodule yet:

```bash
# Run the setup script
python installer/scripts/setup_submodule.py

# Or manually add the submodule
git submodule add https://github.com/john-morrigan/morrigan-releases.git morrigan-releases

# Initialize submodules
git submodule update --init --recursive
```

### Alternative Build Options

```bash
# Build self-contained installer
python installer/scripts/build_selfcontained.py

# Package all available platform installers (if multiple exist)
python installer/scripts/create_distribution.py --all

# Update releases without version tag (uses 'latest')
python installer/scripts/update_releases.py

# Use legacy separate repository mode
python installer/scripts/update_releases.py --no-submodule --version v1.1.0
```

## For End Users

### 1. Download and Extract

Download the installer package for your platform:
- Windows: `morrigan-installer-windows-amd64.zip`
- macOS: `morrigan-installer-darwin-arm64.zip` or `morrigan-installer-darwin-x86_64.zip`
- Linux: `morrigan-installer-linux-x86_64.zip`

Extract the ZIP file to access the installer.

### 2. Run the Installer

**Windows:**
```cmd
# Run as administrator
MorriganInstaller.exe
```

**macOS:**
```bash
# Note: macOS may show security warning for unsigned apps
chmod +x MorriganInstaller
sudo ./MorriganInstaller
```

For macOS security warnings, see MACOS_TROUBLESHOOTING.md

**Linux:**
```bash
chmod +x MorriganInstaller
sudo ./MorriganInstaller
```

### 3. Installation Configuration

The installer will prompt for:
- **Endpoint ID**: Your unique endpoint identifier (required)

The API URL is preconfigured for the Morrigan service.

### 4. Post-Installation

After successful installation:
- Morrigan monitoring service starts automatically
- Configuration files are created in the data directory
- Service is configured to start on system boot
- Installation is complete and ready to use

## Installation Locations

### Windows
- **Program Files**: `C:\Program Files\Morrigan\`
- **Data Directory**: `C:\ProgramData\Morrigan\`
- **Service**: Windows Service Manager

### macOS
- **Program Files**: `/opt/morrigan/`
- **Data Directory**: `~/.morrigan/`
- **Service**: LaunchAgent

### Linux
- **Program Files**: `/opt/morrigan/`
- **Data Directory**: `~/.morrigan/`
- **Service**: systemd service

## Verification

Check installation status:

**Windows:**
```cmd
sc query MorriganService
```

**macOS/Linux:**
```bash
ps aux | grep morrigan
```

## Troubleshooting

**Permission denied:**
- Run installer with administrator privileges

**Python not found:**
- Install Python 3.8+ from python.org
- Ensure Python is in system PATH

**Installation fails:**
- Check internet connection
- Verify sufficient disk space
- Review installer error messages

For detailed troubleshooting, see TROUBLESHOOTING.md  

## Next Steps After Installation

The monitoring system starts automatically and runs in the background. You can:

- **Check Status**: Look for the monitoring process in Task Manager/Activity Monitor
- **View Logs**: Check the log files in the data directory
- **Restart Service**: Use the platform's service management tools
- **Uninstall**: Run the uninstaller script if needed

The system will now monitor your LLM interactions and send anonymized metadata to the configured API endpoint.
